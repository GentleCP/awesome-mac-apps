## Sentry
Copyright (c) 2015 Sentry (https://sentry.io/for/cocoa/)

## AFNetworking
Copyright © 2013-2015 AFNetworking (http://afnetworking.com/)

## BlocksKit
Copyright © 2011-2014 Zachary Waldowski, Alexsander Akers, and the BlocksKit Contributors

## JNWCollectionView
Copyright © 2013 Jonathan Willing

## JNWScrollView
Copyright © 2013 Jonathan Willing

## MMMarkdown
Copyright © 2012-2013 Matt Diephouse.

## iRate
Copyright © 2011 Charcoal Design

## pop
Copyright © 2014, Facebook, Inc. All rights reserved.

## jQuery v1.11.2
Copyright © 2005, 2014 jQuery Foundation, Inc.

## zlib v1.2.5
Copyright © 1995-2010 Jean-loup Gailly and Mark Adler

## OpenSSL
Copyright © 1998-2011 The OpenSSL Project.  All rights reserved.

## libpng v1.2.6
Copyright © 2004, 2006-2015 Glenn Randers-Pehrson
